const Loader= () => {
  return (
    <>
    Loading...
    </>
  )
}

export default Loader