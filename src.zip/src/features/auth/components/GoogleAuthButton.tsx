import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { FaGoogle } from "react-icons/fa6";
import { cn } from '@/lib/utils';
import { useAuth } from '@/features/auth';
import { CgSpinner } from "react-icons/cg";

interface GoogleAuthButtonProps {
  onClick?: () => Promise<void>;
  className?: string;
}

const GoogleAuthButton: React.FC<GoogleAuthButtonProps> = ({ onClick, className }) => {
  const { oAuth, isLoading } = useAuth();

  const handleClick = async () => {
    await oAuth.promptGoogleAuth();
  };

  return (
    <Button
      onClick={handleClick}
      disabled={loading}
      variant="outline"
      className={cn("w-full flex items-center gap-2", className)}
    >
      { isLoading && <CgSpinner className="text-xl" /> }
      <FaGoogle className="text-xl" />
    </Button>
  );
};

export default GoogleAuthButton;