import { useTheme } from './hooks/useTheme';

export { useTheme };