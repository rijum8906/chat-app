export const authRoutes = {
  signIn: '/auth/signIn',
  signUp: '/auth/signUp',
  signOut: '/auth/signOut',
  googleAuth: '/auth/google',
};
