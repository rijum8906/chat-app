const IndexComponent = () => {
  return (
    <>
      Index
    </>
  )
}

export default IndexComponent;

