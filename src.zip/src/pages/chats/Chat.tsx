const Chat = () => {
  return (
    <>
      Chat
    </>
  )
}

export default Chat;

