const ProfileComponent = () => {
  return (
    <>
      Profile
    </>
  )
}

export default ProfileComponent;

