const MyProfileComponent = () => {
  return (
    <>
      MyProfile
    </>
  )
}

export default MyProfileComponent;

