import {Signup} from '@/features/auth';


const SignupPage = () => {
  return (
    <>
      <Signup />
    </>
  )
}

export default SignupPage;

