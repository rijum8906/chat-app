const SigninComponent = () => {
  return (
    <>
      Signin
    </>
  )
}

export default SigninComponent;

