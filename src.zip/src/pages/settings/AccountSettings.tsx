const AccountSettingsComponent = () => {
  return (
    <>
      AccountSettings
    </>
  )
}

export default AccountSettingsComponent;

