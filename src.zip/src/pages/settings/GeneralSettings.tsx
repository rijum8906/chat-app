const GeneralSettingsComponent = () => {
  return (
    <>
      GeneralSettings
    </>
  )
}

export default GeneralSettingsComponent;

