const NotFoundComponent = () => {
  return (
    <>
      NotFound
    </>
  )
}

export default NotFoundComponent;

